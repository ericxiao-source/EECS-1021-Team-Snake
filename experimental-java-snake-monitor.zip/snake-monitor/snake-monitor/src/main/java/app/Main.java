package app;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SnakeMonitorUI ui = new SnakeMonitorUI();
            ui.setVisible(true);
        });
    }
}
