package app;

import java.util.List;

public interface MessageListener {
    void onState(GameState state);
    void onLeaderboard(List<LeaderboardEntry> entries);
    void onEvent(String name, GameState snapshot);
    void onLog(String text);
    void onConnectionChanged(boolean connected);
}
