package app;

public class LeaderboardEntry {
    private final int rank;
    private final int score;
    private final int length;
    private final long survivalMs;

    public LeaderboardEntry(int rank, int score, int length, long survivalMs) {
        this.rank = rank;
        this.score = score;
        this.length = length;
        this.survivalMs = survivalMs;
    }

    public int getRank() {
        return rank;
    }

    public int getScore() {
        return score;
    }

    public int getLength() {
        return length;
    }

    public long getSurvivalMs() {
        return survivalMs;
    }
}
