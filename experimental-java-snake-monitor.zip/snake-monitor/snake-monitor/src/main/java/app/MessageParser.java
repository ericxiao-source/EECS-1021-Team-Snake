package app;

import java.util.ArrayList;
import java.util.List;

public class MessageParser {

    public ParsedMessage parse(String line) {
        if (line == null || line.isBlank()) {
            return null;
        }

        if (line.startsWith("STATE,")) {
            return parseState(line);
        }

        if (line.startsWith("LEADERBOARD,")) {
            return parseLeaderboard(line);
        }

        if (line.startsWith("EVENT,")) {
            return parseEvent(line);
        }

        return new ParsedMessage(ParsedMessage.Type.LOG, line, null, null, null);
    }

    private ParsedMessage parseState(String line) {
        String[] parts = line.split(",");
        if (parts.length < 5) {
            return new ParsedMessage(ParsedMessage.Type.LOG, "Malformed STATE: " + line, null, null, null);
        }

        GameState state = new GameState();
        state.setScreen(parts[1]);

        for (int i = 2; i < parts.length; i++) {
            String[] kv = parts[i].split("=", 2);
            if (kv.length != 2) continue;

            switch (kv[0]) {
                case "score" -> state.setScore(safeParseInt(kv[1]));
                case "length" -> state.setLength(safeParseInt(kv[1]));
                case "time" -> state.setTimeMs(safeParseLong(kv[1]));
            }
        }

        return new ParsedMessage(ParsedMessage.Type.STATE, null, state, null, null);
    }

    private ParsedMessage parseLeaderboard(String line) {
        String payload = line.substring("LEADERBOARD,".length());
        String[] chunks = payload.split(";");
        List<LeaderboardEntry> entries = new ArrayList<>();

        for (String chunk : chunks) {
            String[] items = chunk.split(",");
            if (items.length != 4) continue;

            int rank = safeParseInt(items[0]);
            int score = safeParseInt(items[1]);
            int length = safeParseInt(items[2]);
            long time = safeParseLong(items[3]);

            entries.add(new LeaderboardEntry(rank, score, length, time));
        }

        return new ParsedMessage(ParsedMessage.Type.LEADERBOARD, null, null, entries, null);
    }

    private ParsedMessage parseEvent(String line) {
        String[] parts = line.split(",");
        if (parts.length < 5) {
            return new ParsedMessage(ParsedMessage.Type.LOG, "Malformed EVENT: " + line, null, null, null);
        }

        String eventName = parts[1];
        GameState snapshot = new GameState();

        for (int i = 2; i < parts.length; i++) {
            String[] kv = parts[i].split("=", 2);
            if (kv.length != 2) continue;

            switch (kv[0]) {
                case "score" -> snapshot.setScore(safeParseInt(kv[1]));
                case "length" -> snapshot.setLength(safeParseInt(kv[1]));
                case "time" -> snapshot.setTimeMs(safeParseLong(kv[1]));
            }
        }

        return new ParsedMessage(ParsedMessage.Type.EVENT, null, snapshot, null, eventName);
    }

    private int safeParseInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }

    private long safeParseLong(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (Exception e) {
            return 0L;
        }
    }

    public static class ParsedMessage {
        public enum Type { STATE, LEADERBOARD, EVENT, LOG }

        private final Type type;
        private final String logText;
        private final GameState state;
        private final List<LeaderboardEntry> leaderboard;
        private final String eventName;

        public ParsedMessage(Type type, String logText, GameState state, List<LeaderboardEntry> leaderboard, String eventName) {
            this.type = type;
            this.logText = logText;
            this.state = state;
            this.leaderboard = leaderboard;
            this.eventName = eventName;
        }

        public Type getType() {
            return type;
        }

        public String getLogText() {
            return logText;
        }

        public GameState getState() {
            return state;
        }

        public List<LeaderboardEntry> getLeaderboard() {
            return leaderboard;
        }

        public String getEventName() {
            return eventName;
        }
    }
}
