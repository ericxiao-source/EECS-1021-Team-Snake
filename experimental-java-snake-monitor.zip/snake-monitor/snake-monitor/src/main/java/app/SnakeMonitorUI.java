package app;

import com.fazecast.jSerialComm.SerialPort;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SnakeMonitorUI extends JFrame implements MessageListener {
    private final JComboBox<String> portCombo = new JComboBox<>();
    private final JButton refreshPortsBtn = new JButton("Refresh Ports");
    private final JButton connectBtn = new JButton("Connect");
    private final JButton disconnectBtn = new JButton("Disconnect");

    private final JButton startBtn = new JButton("Start");
    private final JButton pauseBtn = new JButton("Pause");
    private final JButton resumeBtn = new JButton("Resume");
    private final JButton stateBtn = new JButton("Get State");
    private final JButton resetLeaderboardBtn = new JButton("Reset Leaderboard");
    private final JButton showLeaderboardBtn = new JButton("Show Leaderboard");

    private final JLabel connectionLabel = new JLabel("Disconnected");
    private final JLabel screenLabel = new JLabel("Screen: -");
    private final JLabel scoreLabel = new JLabel("Score: -");
    private final JLabel lengthLabel = new JLabel("Length: -");
    private final JLabel timeLabel = new JLabel("Time: -");
    private final JLabel eventLabel = new JLabel("Last Event: -");

    private final JTextArea logArea = new JTextArea();
    private final DefaultTableModel leaderboardModel = new DefaultTableModel(
            new Object[]{"Rank", "Score", "Length", "Survival (s)"}, 0
    );
    private final JTable leaderboardTable = new JTable(leaderboardModel);

    private final SerialManager serialManager = new SerialManager(this);

    public SnakeMonitorUI() {
        setTitle("Snake System Monitor");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        buildUi();
        bindActions();
        loadPorts();
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setBorder(new EmptyBorder(12, 12, 12, 12));
        setContentPane(root);

        JPanel top = new JPanel(new BorderLayout(10, 10));
        root.add(top, BorderLayout.NORTH);

        JPanel connectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        connectionPanel.add(new JLabel("Port:"));
        connectionPanel.add(portCombo);
        portCombo.setPreferredSize(new Dimension(180, 26));
        connectionPanel.add(refreshPortsBtn);
        connectionPanel.add(connectBtn);
        connectionPanel.add(disconnectBtn);
        connectionPanel.add(Box.createHorizontalStrut(20));
        connectionPanel.add(connectionLabel);
        top.add(connectionPanel, BorderLayout.NORTH);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controls.add(startBtn);
        controls.add(pauseBtn);
        controls.add(resumeBtn);
        controls.add(stateBtn);
        controls.add(resetLeaderboardBtn);
        controls.add(showLeaderboardBtn);
        top.add(controls, BorderLayout.SOUTH);

        JPanel center = new JPanel(new GridLayout(1, 2, 12, 12));
        root.add(center, BorderLayout.CENTER);

        JPanel left = new JPanel(new BorderLayout(8, 8));
        center.add(left);

        JPanel statusPanel = new JPanel();
        statusPanel.setLayout(new BoxLayout(statusPanel, BoxLayout.Y_AXIS));
        statusPanel.setBorder(BorderFactory.createTitledBorder("Current State"));
        statusPanel.add(screenLabel);
        statusPanel.add(Box.createVerticalStrut(6));
        statusPanel.add(scoreLabel);
        statusPanel.add(Box.createVerticalStrut(6));
        statusPanel.add(lengthLabel);
        statusPanel.add(Box.createVerticalStrut(6));
        statusPanel.add(timeLabel);
        statusPanel.add(Box.createVerticalStrut(6));
        statusPanel.add(eventLabel);

        left.add(statusPanel, BorderLayout.NORTH);

        logArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(logArea);
        logScroll.setBorder(BorderFactory.createTitledBorder("Serial Log"));
        left.add(logScroll, BorderLayout.CENTER);

        JScrollPane leaderboardScroll = new JScrollPane(leaderboardTable);
        leaderboardScroll.setBorder(BorderFactory.createTitledBorder("Leaderboard"));
        center.add(leaderboardScroll);
    }

    private void bindActions() {
        refreshPortsBtn.addActionListener(e -> loadPorts());

        connectBtn.addActionListener(e -> {
            String selected = (String) portCombo.getSelectedItem();
            if (selected != null) {
                serialManager.connect(selected);
            }
        });

        disconnectBtn.addActionListener(e -> serialManager.disconnect());

        startBtn.addActionListener(e -> serialManager.sendCommand("CMD,START"));
        pauseBtn.addActionListener(e -> serialManager.sendCommand("CMD,PAUSE"));
        resumeBtn.addActionListener(e -> serialManager.sendCommand("CMD,RESUME"));
        stateBtn.addActionListener(e -> serialManager.sendCommand("CMD,GET_STATE"));
        resetLeaderboardBtn.addActionListener(e -> serialManager.sendCommand("CMD,RESET_LEADERBOARD"));
        showLeaderboardBtn.addActionListener(e -> serialManager.sendCommand("CMD,SHOW_LEADERBOARD"));
    }

    private void loadPorts() {
        portCombo.removeAllItems();
        for (SerialPort port : serialManager.listPorts()) {
            portCombo.addItem(port.getSystemPortName());
        }
    }

    @Override
    public void onState(GameState state) {
        SwingUtilities.invokeLater(() -> {
            screenLabel.setText("Screen: " + state.getScreen());
            scoreLabel.setText("Score: " + state.getScore());
            lengthLabel.setText("Length: " + state.getLength());
            timeLabel.setText("Time: " + (state.getTimeMs() / 1000.0) + " s");
        });
    }

    @Override
    public void onLeaderboard(List<LeaderboardEntry> entries) {
        SwingUtilities.invokeLater(() -> {
            leaderboardModel.setRowCount(0);
            for (LeaderboardEntry entry : entries) {
                leaderboardModel.addRow(new Object[]{
                        entry.getRank(),
                        entry.getScore(),
                        entry.getLength(),
                        entry.getSurvivalMs() / 1000.0
                });
            }
        });
    }

    @Override
    public void onEvent(String name, GameState snapshot) {
        SwingUtilities.invokeLater(() -> {
            eventLabel.setText("Last Event: " + name);
            if (snapshot != null) {
                scoreLabel.setText("Score: " + snapshot.getScore());
                lengthLabel.setText("Length: " + snapshot.getLength());
                timeLabel.setText("Time: " + (snapshot.getTimeMs() / 1000.0) + " s");
            }
        });
    }

    @Override
    public void onLog(String text) {
        SwingUtilities.invokeLater(() -> logArea.append(text + "\n"));
    }

    @Override
    public void onConnectionChanged(boolean connected) {
        SwingUtilities.invokeLater(() -> connectionLabel.setText(connected ? "Connected" : "Disconnected"));
    }
}
