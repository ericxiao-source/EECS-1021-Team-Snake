package app;

import com.fazecast.jSerialComm.SerialPort;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class SerialManager {
    private SerialPort serialPort;
    private Thread readerThread;
    private volatile boolean running = false;

    private final MessageParser parser = new MessageParser();
    private final MessageListener listener;

    public SerialManager(MessageListener listener) {
        this.listener = listener;
    }

    public SerialPort[] listPorts() {
        return SerialPort.getCommPorts();
    }

    public boolean connect(String portName) {
        disconnect();

        serialPort = SerialPort.getCommPort(portName);
        serialPort.setBaudRate(115200);
        serialPort.setNumDataBits(8);
        serialPort.setNumStopBits(1);
        serialPort.setParity(SerialPort.NO_PARITY);
        serialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 1000, 0);

        if (!serialPort.openPort()) {
            listener.onLog("Failed to open port: " + portName);
            listener.onConnectionChanged(false);
            return false;
        }

        running = true;
        readerThread = new Thread(this::readLoop, "serial-reader");
        readerThread.start();

        listener.onLog("Connected to " + portName);
        listener.onConnectionChanged(true);
        return true;
    }

    public void disconnect() {
        running = false;

        if (readerThread != null && readerThread.isAlive()) {
            try {
                readerThread.join(500);
            } catch (InterruptedException ignored) {
            }
        }

        if (serialPort != null && serialPort.isOpen()) {
            serialPort.closePort();
        }

        listener.onConnectionChanged(false);
    }

    public void sendCommand(String cmd) {
        if (serialPort == null || !serialPort.isOpen()) {
            listener.onLog("Cannot send; serial port not connected.");
            return;
        }

        try {
            OutputStream out = serialPort.getOutputStream();
            out.write((cmd + "\n").getBytes(StandardCharsets.UTF_8));
            out.flush();
            listener.onLog("TX: " + cmd);
        } catch (Exception e) {
            listener.onLog("Send error: " + e.getMessage());
        }
    }

    private void readLoop() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(serialPort.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while (running && (line = reader.readLine()) != null) {
                final String incoming = line.trim();
                if (incoming.isEmpty()) continue;

                listener.onLog("RX: " + incoming);
                MessageParser.ParsedMessage parsed = parser.parse(incoming);
                if (parsed == null) continue;

                switch (parsed.getType()) {
                    case STATE -> listener.onState(parsed.getState());
                    case LEADERBOARD -> listener.onLeaderboard(parsed.getLeaderboard());
                    case EVENT -> listener.onEvent(parsed.getEventName(), parsed.getState());
                    case LOG -> listener.onLog(parsed.getLogText());
                }
            }
        } catch (Exception e) {
            listener.onLog("Read error: " + e.getMessage());
        } finally {
            listener.onConnectionChanged(false);
        }
    }
}
