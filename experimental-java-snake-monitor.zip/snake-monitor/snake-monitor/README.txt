# Snake Game Monitor and Persistent Leaderboard Tracking

## Overview
This java implementation was meant to wirelessly communicate with the Snake Game on Raspberry Pi Pico 2 W with SSD1306 OLED system to persistently track the total score of a user and push that scroe to a database.
**VERY EXPERIMENTAL, NOT INTENDED FOR SERIOUS CONSIDERATION**

note: development ended after realization that we lacked the required communication hardware.